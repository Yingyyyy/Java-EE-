package com.ehall.dao;

import java.util.List;

import com.ehall.po.Appointment;
import com.ehall.po.Customer;


public interface AppointmentDao {
	//ԤԼ�б�
		public List<Appointment> selectAppointmentList(Appointment ap);
		
		// ��¼��
		public Integer selectAppointmentCount(Appointment ap);
		
		// ɾ��ԤԼ
				int deleteAppointment (Integer id);

				 //����ԤԼ
				public int createAppointment(Appointment Appointment);
		
				// ͨ��no��ѯԤԼ
				public Appointment getAppointmentByNo(Integer no);
				
				//������
				public int updateAppointment(Appointment appointment);
}
