package com.ehall.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ehall.po.Customer;


public interface CustomerDao {
	//�ͻ��б�
	public List<Customer> selectCustomerList(Customer customer);
	
	// �ͻ���
		public Integer selectCustomerListCount(Customer customer);
		
	   //������Ա
		public int createCustomer(Customer customer);

		// ɾ���ͻ�
		int deleteCustomer (Integer id);
		
		// ͨ��id��ѯ�ͻ�
		public Customer getCustomerById(Integer id);
		
		// ��ֵ
		public int updateCustomer(Customer customer);

		

}
