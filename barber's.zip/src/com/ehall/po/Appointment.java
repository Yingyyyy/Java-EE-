package com.ehall.po;

import java.io.Serializable;
import java.util.Date;

public class Appointment implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer no; //ԤԼ���
	private String customer_id; //�ͻ����
	private String customer_name;//�ͻ�����
	private String service;//�ͻ�����
	private String appoint;//�ͻ�ԤԼ����
	private String status;//���״̬
	private Integer start;
	private Integer rows;
	
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	
	
	
	public String getAppoint() {
		return appoint;
	}
	public void setAppoint(String appoint) {
		this.appoint = appoint;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	

}
