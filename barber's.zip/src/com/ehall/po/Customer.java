package com.ehall.po;

import java.io.Serializable;

public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;
	private String customer_id;
	private String customer_name;
	private float money;
	private float recharge;
	private Integer start;
	private Integer rows;
	
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public float getMoney() {
		return money;
	}
	public void setMoney(float money) {
		this.money = money;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	
	public float getRecharge() {
		return recharge;
	}
	public void setRecharge(float recharge) {
		this.recharge = recharge;
	}
	@Override
	public String toString() {
		return "Customer [customer_id = "+customer_id+" customer_name = "+customer_name+" money ="+money+"]";
	}

}
