package com.ehall.service;

import com.ehall.common.utils.Page;
import com.ehall.po.Appointment;
import com.ehall.po.Customer;


public interface AppointmentService {
	// ��ѯ�ͻ��б�
		public Page<Appointment> findAppointmentList(Integer page, Integer rows);
		
		// ɾ����Ա
		public int deleteAppointment(Integer id);

		public int createAppointment(Appointment appointment);
		
		// ͨ��no��ѯԤԼ
		public Appointment getAppointmentByNo(Integer no);
		
		// ������
		public int updateAppointment(Appointment appointment);

}
