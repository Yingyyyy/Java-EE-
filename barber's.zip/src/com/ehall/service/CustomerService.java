package com.ehall.service;

import com.ehall.common.utils.Page;
import com.ehall.po.Customer;

public interface CustomerService {
	// ��ѯ�ͻ��б�
	public Page<Customer> findCustomerList(Integer page, Integer rows);
		

	//������Ա
	public int createCustomer(Customer customer);
	
	// ɾ����Ա
	public int deleteCustomer(Integer id);
		
	// ͨ��id��ѯ�ͻ�
		public Customer getCustomerById(Integer id);
		
		// ��ֵ
		public int updateCustomer(Customer customer);
	
}
