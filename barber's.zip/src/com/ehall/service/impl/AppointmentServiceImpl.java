package com.ehall.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ehall.common.utils.Page;
import com.ehall.dao.AppointmentDao;

import com.ehall.po.Appointment;
import com.ehall.po.Customer;
import com.ehall.service.AppointmentService;

@Service("appointmentService")
@Transactional
public class AppointmentServiceImpl implements AppointmentService {
	@Autowired
    private AppointmentDao apDao;

	@Override
	public Page<Appointment> findAppointmentList(Integer page, Integer rows) {
		Appointment ap = new Appointment();
		// ��ǰҳ
		ap.setStart((page-1) * rows) ;
				// ÿҳ��
		ap.setRows(rows);
				// ��ѯ�ͻ��б�
				List<Appointment> aps = apDao.selectAppointmentList(ap);
				
				// ��ѯ�ͻ��б��ܼ�¼��
				Integer count = apDao.selectAppointmentCount(ap);
				
				// ����Page���ض���
				Page<Appointment> result = new Page<>();
				result.setPage(page);
				result.setRows(aps);
				result.setSize(rows);
				result.setTotal(count);
				return result;
	}
	
	/**
	 * ɾ��ԤԼ
	 */
	@Override
	public int deleteAppointment(Integer id) {
	    return apDao.deleteAppointment(id);	
	}
	
	/**
	 * �����ͻ�
	 */
	@Override
	public int createAppointment(Appointment appointment) {
	    return apDao.createAppointment(appointment);
	}

	@Override
	public Appointment getAppointmentByNo(Integer no) {
		Appointment ap = apDao.getAppointmentByNo(no);
	    return ap;		
	}

	@Override
	public int updateAppointment(Appointment appointment) {
		return apDao.updateAppointment(appointment);
	}

}
