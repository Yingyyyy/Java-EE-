package com.ehall.service.impl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ehall.common.utils.Page;
import com.ehall.dao.CustomerDao;
import com.ehall.po.Customer;
import com.ehall.service.CustomerService;

@Service("customerService")
@Transactional

public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerDao customerDao;
    
 
	public Page<Customer> findCustomerList(Integer page, Integer rows) {
		Customer customer = new Customer();
		// ��ǰҳ
				customer.setStart((page-1) * rows) ;
				// ÿҳ��
				customer.setRows(rows);
				// ��ѯ�ͻ��б�
				List<Customer> customers = customerDao.selectCustomerList(customer);
				
				// ��ѯ�ͻ��б��ܼ�¼��
				Integer count = customerDao.selectCustomerListCount(customer);
				
				// ����Page���ض���
				Page<Customer> result = new Page<>();
				result.setPage(page);
				result.setRows(customers);
				result.setSize(rows);
				result.setTotal(count);
				return result;
	}
	/**
	 * �����ͻ�
	 */
	@Override
	public int createCustomer(Customer customer) {
	    return customerDao.createCustomer(customer);
	}
	
	/**
	 * ɾ���ͻ�
	 */
	@Override
	public int deleteCustomer(Integer id) {
	    return customerDao.deleteCustomer(id);	
	}

	/**
	 * ͨ��id��ѯ�ͻ�
	 */
	@Override
	public Customer getCustomerById(Integer id) {	
	    Customer customer = customerDao.getCustomerById(id);
	    return customer;		
	}

	/**
	 * ���¿ͻ�
	 */
	@Override
	public int updateCustomer(Customer customer) {
	    return customerDao.updateCustomer(customer);
	}

	
	
	

}
