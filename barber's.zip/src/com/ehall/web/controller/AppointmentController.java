package com.ehall.web.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ehall.common.utils.Page;
import com.ehall.po.Appointment;
import com.ehall.po.Customer;
import com.ehall.service.AppointmentService;


@Controller
public class AppointmentController {
       @Autowired
       private AppointmentService appointmentService;
       
       @RequestMapping(value = "/appointment/list.action")
		public String list(@RequestParam(defaultValue="1")Integer page,
				@RequestParam(defaultValue="5")Integer rows,  Model model) {
			// ������ѯ���пͻ�
			Page<Appointment> appointments = appointmentService.findAppointmentList(page, rows);
			model.addAttribute("page", appointments);
			
			return "appointment";
		}
       
       /**
		 * ɾ���ͻ�
		 */
		@RequestMapping("/appointment/delete.action")
		@ResponseBody
		public String appointmentDelete(Integer id) {
		    int rows = appointmentService.deleteAppointment(id);
		    if(rows > 0){			
		        return "OK";
		    }else{
		        return "FAIL";			
		    }
		}
		
		/**
		 * �����ͻ�
		 */
		@RequestMapping("/appointment/create.action")
		@ResponseBody
		public String customerCreate(Appointment appointment,HttpSession session) {
		    
		    // ִ��Service���еĴ������������ص�����Ӱ�������
		    int rows = appointmentService.createAppointment(appointment);
		    if(rows > 0){
		        return "OK";
		    }else{
		        return "FAIL";
		    }
		}
		
		/**
		 * ͨ��no��ȡԤԼ��Ϣ
		 */
		@RequestMapping("/appointment/getAppointmentByNo.action")
		@ResponseBody
		public Appointment getAppointmentByNo(Integer no) {
			Appointment appointment = appointmentService.getAppointmentByNo(no);
		    return appointment;
		}
		
		@RequestMapping("/appointment/update.action")
		@ResponseBody
		public String appointmentUpdate(Appointment appointment) {
		    int rows = appointmentService.updateAppointment(appointment);
		    
		    if(rows > 0){
		        return "OK";
		    }else{
		        return "FAIL";
		    }
		}
}
