package com.ehall.test;


import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ehall.common.utils.Page;
import com.ehall.dao.CustomerDao;
import com.ehall.po.Customer;
import com.ehall.service.CustomerService;


public class findAllCustomerTest {
	
	@Test
	public void xmlTest() {
			ApplicationContext applicationContext = 
			   new ClassPathXmlApplicationContext("applicationContext.xml");
			// ��ȡAccountDaoʵ��
			Customer c = null;
			CustomerService accountDao =  applicationContext.getBean(CustomerService.class);
			Page<Customer> list = accountDao.findCustomerList(1,5);
			
			
			
			
	}

}
